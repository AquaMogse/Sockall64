#ifndef MRITYUNJAY_INIT_H
#define MRITYUNJAY_INIT_H

bool isPremium = false;
char version[69]="com.tencent.ig";
float healthbuff[2],health;

#endif