#ifndef MRITYUNJAY_OFFSETS_H
#define MRITYUNJAY_OFFSETS_H

//@Nikhil_Mrityunjay
namespace Offsets {

 // PUBG ------ >
uintptr_t GWORLDGLOBAL = 0xcaae430;
uintptr_t GNAMEGLOBAL = 0xc43d700;

// BGMI ------ >
uintptr_t GWORLDBGMI = 0xc4e2630;
uintptr_t GNAMEBGMI = 0xc065380;


uintptr_t MinLOD = 0x830;
uintptr_t FixAttachInfoList = 0x1b0;
uintptr_t ParachuteEquipItems = 0x1c0;

uintptr_t WalkSpeed = 0x2758;
uintptr_t Role = 0x150;
uintptr_t Children = 0x1a0;
uintptr_t RootComponent = 0x1b0;
uintptr_t AttachSocket = 0x30;
uintptr_t DrawShootLineTime = 0x13C;
uintptr_t Controller = 0x430;
uintptr_t ControlRotation = 0x428;
uintptr_t Mesh = 0x458;
uintptr_t MaxWalkSpeed = 0x1f4;
uintptr_t MaxWalkSpeedCrouched = 0x1f8;
uintptr_t PlayerCameraManager = 0x490;
uintptr_t MinimalViewInfo = 0x10;
uintptr_t MovementCharacter = 0x460;
uintptr_t CurrentVehicle = 0xda8;
uintptr_t ReplicatedMovement = 0xb0;
uintptr_t Velocity = 0x12c;
uintptr_t CameraCache = 0x470;
uintptr_t CameraCache2 = 0xff0;
uintptr_t FieldOfView = 0x32c;
uintptr_t PlayerName = 0x8a8;
uintptr_t Nation = 0x8b8;
uintptr_t PlayerUID = 0x8d0;
uintptr_t TeamID = 0x8f0;
uintptr_t CampID = 0x8f8;
uintptr_t bIsAI = 0x9a1;
uintptr_t bDead = 0xd7c;
uintptr_t Health = 0xd60;
uintptr_t bIsGunADS = 0xff1;
uintptr_t bIsWeaponFiring = 0x15c8;
uintptr_t ParachuteComponent = 0x15b0;
uintptr_t ThirdPersonCameraComponent = 0x1a28;
uintptr_t CustomSpringArmComponent = 0x1a18;
uintptr_t STCharacterMovement = 0x1b58;
uintptr_t WeaponManagerComponent = 0x2238;
uintptr_t SwitchWeaponSpeedScale = 0x2830;
uintptr_t STPlayerController = 0x3de0;
uintptr_t CurBulletNumInClip = 0xea0;
uintptr_t ShootWeaponEntityComp = 0xff8;
uintptr_t CurMaxBulletNumInOneClip = 0xec0;
uintptr_t CurrWeapon = 0x500;
uintptr_t UploadInterval = 0x178;
uintptr_t VehicleCommon = 0x9d8;
uintptr_t VHealthMax = 0x2a0;
uintptr_t VHealth = 0x2a4;
uintptr_t VFuelMax = 0x314;
uintptr_t VFuel = 0x318;
uintptr_t BulletFireSpeed = 0x4f8;
uintptr_t RecoilInfo = 0xab8;
uintptr_t ShootInterval = 0x530;
uintptr_t WeaponWarnUpTime = 0x624;
uintptr_t WeaponHitPartCoff = 0x62c;
uintptr_t WeaponHitPartCoffZombie = 0x640;
uintptr_t BaseImpactDamage = 0x654;
uintptr_t BulletMomentum = 0x65c;
uintptr_t MaxDamageRate = 0x748;
uintptr_t DamageImpulse = 0x8cc;
uintptr_t AutoAimingConfig = 0x990;
uintptr_t AccessoriesVRecoilFactor = 0xb28;
uintptr_t AccessoriesHRecoilFactor = 0xb2c;
uintptr_t AccessoriesRecoveryFactor = 0xb30;
uintptr_t GameDeviationFactor = 0xba0;
uintptr_t RecoilKickADS = 0xc58;
uintptr_t ExtraHitPerformScale = 0xc5c;
uintptr_t AnimationKick = 0xc74;
uintptr_t ViewPitchMin = 0x1c9c;
uintptr_t ViewPitchMax = 0x1ca0;
uintptr_t ViewYawMin = 0x1ca4;
uintptr_t ViewYawMax = 0x1ca8;
uintptr_t RecoilModifierStand = 0x50;
uintptr_t RecoilModifierCrouch = 0x54;
uintptr_t RecoilModifierProne = 0x58;
uintptr_t LastRenderTime = 0x400;
uintptr_t LastRenderTimeOnScreen = 0x404;
uintptr_t AcknowledgedPawn = 0x470;
uintptr_t LocalTeamID = 0x860;
uintptr_t NearDeathBreath = 0x18e0;
uintptr_t NearDeatchComponent = 0x18c0;
uintptr_t BreathMax = 0x16c;
uintptr_t CurrentFallSpeed = 0x1cc;

}

#endif
